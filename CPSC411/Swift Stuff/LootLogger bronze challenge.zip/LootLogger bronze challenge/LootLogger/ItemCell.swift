//
//  ItemCell.swift
//  LootLogger
//
//  Created by csuftitan on 10/3/22.
//

import UIKit

class ItemCell : UITableViewCell {
//    @IBOutlet var nameLabel: UILabel!
//    @IBOutlet var serialNumberLabel: UILabel!
//    @IBOutlet var valueLabel: UILabel!
}
