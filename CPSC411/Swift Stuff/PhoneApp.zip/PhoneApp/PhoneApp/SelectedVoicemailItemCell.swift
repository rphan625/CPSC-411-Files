//
//  SelectedVoicemailItemCell.swift
//  PhoneApp
//
//  Created by csuftitan on 10/29/22.
//

import UIKit

class SelectedVoicemailItemCell:UITableViewCell {
    @IBOutlet var selectedVoicemailPhoneNumber: UILabel!
    @IBOutlet var selectedVoicemailDate: UILabel!
    @IBOutlet var selectedVoicemailLocation: UILabel!
    @IBOutlet var selectedVoicemailTime: UILabel!
}
