//
//  FavoriteItemCell.swift
//  PhoneApp
//
//  Created by csuftitan on 10/17/22.
//

import UIKit

class FavoriteItemCell : UITableViewCell {
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var phoneTypeLabel: UILabel!
    @IBOutlet var initialLabel: UILabel!
}
