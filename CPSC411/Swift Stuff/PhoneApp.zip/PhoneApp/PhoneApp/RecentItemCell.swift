//
//  RecentItemCell.swift
//  PhoneApp
//
//  Created by csuftitan on 10/22/22.
//

import UIKit

class RecentItemCell : UITableViewCell {
    @IBOutlet var recentNameLabel: UILabel!
    @IBOutlet var recentPhoneTypeLabel: UILabel!
    @IBOutlet var recentTimeLabel: UILabel!
    @IBOutlet var recentPhoneImage: UILabel!
}
