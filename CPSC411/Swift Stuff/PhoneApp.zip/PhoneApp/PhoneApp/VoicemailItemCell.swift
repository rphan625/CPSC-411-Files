//
//  VoicemailItemCell.swift
//  PhoneApp
//
//  Created by csuftitan on 10/29/22.
//

import UIKit

class VoicemailItemCell : UITableViewCell {
    @IBOutlet var voicemailGroupName: UILabel!
}
