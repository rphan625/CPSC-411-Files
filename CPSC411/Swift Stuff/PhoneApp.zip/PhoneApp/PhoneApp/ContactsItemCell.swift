//
//  ContactsItemCell.swift
//  PhoneApp
//
//  Created by csuftitan on 10/24/22.
//

import UIKit

class ContactsItemCell : UITableViewCell {
    @IBOutlet var contactsListName : UILabel!
    @IBOutlet var contactsContactCount: UILabel!
}
