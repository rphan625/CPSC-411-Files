//
//  SelectedContactsListsCell.swift
//  PhoneApp
//
//  Created by csuftitan on 10/25/22.
//

import UIKit

class SelectedContactsListsCell:UITableViewCell {
    @IBOutlet var selectedContactsNameLabel: UILabel!
}
