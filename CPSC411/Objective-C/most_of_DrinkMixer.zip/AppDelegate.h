//
//  AppDelegate.h
//  DrinkMixer
//
//  Created by William McCarthy on 02/8/2022.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

