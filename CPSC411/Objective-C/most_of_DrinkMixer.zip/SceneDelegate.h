//
//  SceneDelegate.h
//  DrinkMixer
//
//  Created by William McCarthy on 02/8/2022.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

