//
//  DrinkConstants.h
//  Drinks
//
//  Created by csuftitan on 9/12/22.
//

#ifndef DrinkConstants_h
#define DrinkConstants_h

#define NAME_KEY        @"name"
#define INGREDIENTS_KEY @"ingredients"
#define DIRECTIONS_KEY  @"directions"


#endif /* DrinkConstants_h */
