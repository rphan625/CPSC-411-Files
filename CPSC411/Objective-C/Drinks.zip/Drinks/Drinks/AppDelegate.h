//
//  AppDelegate.h
//  Drinks
//
//  Created by csuftitan on 9/7/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

