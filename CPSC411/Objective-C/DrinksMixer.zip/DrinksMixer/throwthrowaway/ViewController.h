//
//  ViewController.h
//  throwthrowaway
//
//  Created by csuftitan on 9/21/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>


@end

