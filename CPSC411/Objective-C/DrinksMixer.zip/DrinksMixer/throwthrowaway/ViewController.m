//
//  ViewController.m
//  throwthrowaway
//
//  Created by csuftitan on 9/21/22.
//

#import "ViewController.h"
#import "DetailViewController.h"
//#import "AddDrinkViewController.h"
#import "DrinkConstants.h"

@interface ViewController () {
    UITableView *tableView;
    NSMutableArray *drinks;
}

@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, retain) NSMutableArray *drinks;

@end

@implementation ViewController

@synthesize tableView=tableView, drinks=drinks;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    drinks = [[NSMutableArray alloc] initWithObjects:@"Firecracker", @"Lemon Drop", @"Mojito", @"Whiskey Sour", nil];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"DrinkDirections" ofType:@"plist"];
    self.drinks = [NSMutableArray arrayWithContentsOfFile:path];
}

#pragma mark - Table View Datasource Protocol

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    static NSString* cellIdentifier = @"drinkCell";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
      cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
// Configure the cell.
    cell.textLabel.text = [[drinks objectAtIndex:indexPath.row] objectForKey:NAME_KEY];
    return cell;
}
- (NSInteger)numberOfSectionsInTableView { return 1; }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.drinks count];
}

#pragma mark -
#pragma mark Table View Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    NSLog(@"in didSelectViewRowAtIndexPath");
    // pass the selected object to new view controller

    
//    if (!self.editing) {
      DetailViewController *detailVC = [self.storyboard instantiateViewControllerWithIdentifier:@"detailVC"];
      detailVC.drink = [drinks objectAtIndex:indexPath.row];
      [self.navigationController pushViewController:detailVC animated:YES];
//    } else {
//      AddDrinkViewController *editingDrinkVC = [self.storyboard instantiateViewControllerWithIdentifier:@"addDrinkVC"];
//      editingDrinkVC.drinkName = [drinks objectAtIndex:indexPath.row];
//      editingDrinkVC.drinkArray = drinks;
//
//      UINavigationController *editingNavCon = [[UINavigationController alloc] initWithRootViewController:editingDrinkVC];
//      [self presentViewController:editingNavCon animated:YES completion:nil];
//    }
}



@end
