//
//  SceneDelegate.h
//  throwthrowaway
//
//  Created by csuftitan on 9/21/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

