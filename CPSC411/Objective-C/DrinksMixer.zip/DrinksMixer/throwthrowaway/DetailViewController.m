//
//  DetailViewController.m
//  throwthrowaway
//
//  Created by csuftitan on 9/21/22.
//

#import "DetailViewController.h"
#import "DrinkConstants.h"

@interface DetailViewController() {

}

@end



@implementation DetailViewController
@synthesize drink=drink_, drinkName=drinkName_, ingredients=ingredients_, directions=directions_;

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // Set up our UI with the provided drink
    
    self.drinkName.text = [self.drink objectForKey:NAME_KEY];
    self.ingredients.text = [self.drink objectForKey:INGREDIENTS_KEY];
    self.directions.text = [self.drink objectForKey:DIRECTIONS_KEY];
//    NSLog(@"%@", self.drinkName.text);
//    NSLog(@"This code should run!");
    
    
}

@end
