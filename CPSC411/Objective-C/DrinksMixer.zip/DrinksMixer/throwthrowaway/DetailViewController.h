//
//  DetailViewController.h
//  throwthrowaway
//
//  Created by csuftitan on 9/21/22.
//

#ifndef DetailViewController_h
#define DetailViewController_h

#include <UIKit/UIKit.h>

@interface DetailViewController: UIViewController {
@private
    UITextField *drinkName_;
    UITextView *ingredients_;
    UITextView *directions_;
    NSDictionary *drink_;
}

@property (strong, nonatomic) IBOutlet UITextField *drinkName;
@property (strong, nonatomic) IBOutlet UITextView *ingredients;
@property (strong, nonatomic) IBOutlet UITextView *directions;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) NSDictionary *drink;

@end

#endif /* DetailViewController_h */
