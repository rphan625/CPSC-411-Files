//
//  DrinkConstants.h
//  DrinkMixer
//
//  Created by William McCarthy on 11/8/2022.
//

#ifndef DrinkConstants_h
#define DrinkConstants_h


#define  NAME_KEY         @"name"
#define  INGREDIENTS_KEY  @"ingredients"
#define  DIRECTIONS_KEY   @"directions"


#endif /* DrinkConstants_h */
