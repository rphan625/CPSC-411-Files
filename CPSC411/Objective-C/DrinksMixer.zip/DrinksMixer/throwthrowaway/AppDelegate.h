//
//  AppDelegate.h
//  throwthrowaway
//
//  Created by csuftitan on 9/21/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

