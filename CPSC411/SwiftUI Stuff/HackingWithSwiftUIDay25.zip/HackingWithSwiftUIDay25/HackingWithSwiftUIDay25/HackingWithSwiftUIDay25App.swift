//
//  HackingWithSwiftUIDay25App.swift
//  HackingWithSwiftUIDay25
//
//  Created by csuftitan on 11/16/22.
//

import SwiftUI

@main
struct HackingWithSwiftUIDay25App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
