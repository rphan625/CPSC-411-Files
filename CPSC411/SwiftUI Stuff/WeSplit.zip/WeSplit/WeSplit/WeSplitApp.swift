//
//  WeSplitApp.swift
//  WeSplit
//
//  Created by csuftitan on 11/10/22.
//

import SwiftUI

@main
struct WeSplitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
