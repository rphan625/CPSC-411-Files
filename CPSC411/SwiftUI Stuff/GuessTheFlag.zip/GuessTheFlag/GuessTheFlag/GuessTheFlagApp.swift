//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by csuftitan on 11/12/22.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
