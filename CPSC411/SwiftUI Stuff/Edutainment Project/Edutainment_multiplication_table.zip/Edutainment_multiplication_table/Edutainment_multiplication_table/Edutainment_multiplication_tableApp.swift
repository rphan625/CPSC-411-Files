//
//  Edutainment_multiplication_tableApp.swift
//  Edutainment_multiplication_table
//
//  Created by csuftitan on 11/25/22.
//

import SwiftUI

@main
struct Edutainment_multiplication_tableApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
