//
//  BetterRestApp.swift
//  BetterRest
//
//  Created by csuftitan on 11/17/22.
//

import SwiftUI

@main
struct BetterRestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
