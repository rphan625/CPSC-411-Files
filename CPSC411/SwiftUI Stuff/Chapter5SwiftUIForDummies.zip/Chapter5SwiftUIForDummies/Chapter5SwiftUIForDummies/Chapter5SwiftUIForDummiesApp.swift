//
//  Chapter5SwiftUIForDummiesApp.swift
//  Chapter5SwiftUIForDummies
//
//  Created by csuftitan on 11/30/22.
//

import SwiftUI

@main
struct Chapter5SwiftUIForDummiesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
