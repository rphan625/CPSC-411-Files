//
//  Connect4App.swift
//  Connect4
//
//  Created by csuftitan on 12/12/22.
//

import SwiftUI

@main
struct Connect4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
