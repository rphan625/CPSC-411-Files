//
//  iExpenseApp.swift
//  iExpense
//
//  Created by csuftitan on 11/25/22.
//

import SwiftUI

@main
struct iExpenseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
