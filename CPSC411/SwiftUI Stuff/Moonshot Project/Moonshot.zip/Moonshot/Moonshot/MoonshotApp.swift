//
//  MoonshotApp.swift
//  Moonshot
//
//  Created by csuftitan on 11/30/22.
//

import SwiftUI

@main
struct MoonshotApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
