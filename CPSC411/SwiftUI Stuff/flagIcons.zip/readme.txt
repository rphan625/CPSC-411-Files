Iconset: 2400 flags (https://www.iconfinder.com/iconsets/flags_gosquared)
Author: GoSquared (https://www.gosquared.com/)
License: Free for commercial use ()
Download date: 2022-11-30