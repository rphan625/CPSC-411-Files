//
//  tictactoeApp.swift
//  tictactoe
//
//  Created by csuftitan on 11/9/22.
//

import SwiftUI

@main
struct tictactoeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
